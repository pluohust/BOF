#ifndef PERL_HOOKS_H
#define PERL_HOOKS_H

#include "atheme_perl.h"

void enable_perl_hook_handler(const char * hookname);
void disable_perl_hook_handler(const char * hookname);

#endif
