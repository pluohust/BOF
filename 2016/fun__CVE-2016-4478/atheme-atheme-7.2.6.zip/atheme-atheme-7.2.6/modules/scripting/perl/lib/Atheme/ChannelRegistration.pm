package Atheme::ChannelRegistration;

use strict;
use warnings;

our @ISA = qw/Atheme::Object/;

1;

